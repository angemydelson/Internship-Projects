package jredis;


public class Programa {

	public static void main(String[] args) {
		Utils.menu();
	}
}
